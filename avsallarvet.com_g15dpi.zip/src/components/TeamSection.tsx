import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Star, Award, Heart } from 'lucide-react';

export function TeamSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const teamMembers = [
    {
      name: 'Dr. Ahmet Yılmaz',
      title: 'Baş Veteriner Hekim',
      specialization: 'Küçük Hayvan Hekimliği',
      experience: '15 Yıl',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      description: 'Küçük hayvan hekimliği alanında uzman, özellikle cerrahi işlemler konusunda deneyimli.'
    },
    {
      name: 'Dr. Ayşe Demir',
      title: 'Veteriner Hekim',
      specialization: 'İç Hastalıklar',
      experience: '10 Yıl',
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      description: 'İç hastalıklar ve teşhis konularında uzman, hayvan davranışları konusunda eğitimli.'
    },
    {
      name: 'Dr. Mehmet Kaya',
      title: 'Veteriner Hekim',
      specialization: 'Ortopedi & Cerrahi',
      experience: '12 Yıl',
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      description: 'Ortopedik cerrahi ve travma vakalarında uzman, modern cerrahi teknikleri konusunda deneyimli.'
    }
  ];

  return (
    <section id="team" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Uzman Ekibimiz
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Alanında uzman veteriner hekimlerimiz ile sevimli dostlarınızın sağlığı güvende
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="group bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-6 hover:shadow-2xl transition-all duration-300"
              whileHover={{ y: -10 }}
            >
              <div className="relative mb-6">
                <div className="w-32 h-32 mx-auto rounded-full overflow-hidden ring-4 ring-white shadow-lg">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-blue-600 to-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {member.experience}
                  </div>
                </div>
              </div>

              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-800 mb-2">
                  {member.name}
                </h3>
                <p className="text-blue-600 font-semibold mb-1">
                  {member.title}
                </p>
                <p className="text-gray-600 text-sm mb-4">
                  {member.specialization}
                </p>
                <p className="text-gray-700 text-sm mb-6">
                  {member.description}
                </p>

                {/* Rating */}
                <div className="flex justify-center items-center space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Badges */}
                <div className="flex justify-center space-x-2">
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-xs flex items-center">
                    <Award className="w-3 h-3 mr-1" />
                    Uzman
                  </div>
                  <div className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-xs flex items-center">
                    <Heart className="w-3 h-3 mr-1" />
                    Sevecen
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Team Stats */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-16 bg-gradient-to-r from-blue-600 to-green-500 rounded-2xl p-8 text-white"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <h3 className="text-3xl font-bold mb-2">37+</h3>
              <p className="text-blue-100">Yıl Toplam Deneyim</p>
            </div>
            <div>
              <h3 className="text-3xl font-bold mb-2">5000+</h3>
              <p className="text-blue-100">Başarılı Tedavi</p>
            </div>
            <div>
              <h3 className="text-3xl font-bold mb-2">%98</h3>
              <p className="text-blue-100">Müşteri Memnuniyeti</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
