import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Stethoscope, Syringe, Scissors, Tooth, FlaskConical, Heart } from 'lucide-react';

export function ServicesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const services = [
    {
      icon: Stethoscope,
      title: 'Genel Muayene',
      description: 'Kapsamlı sağlık kontrolü ve teşhis hizmetleri',
      image: 'https://images.unsplash.com/photo-1603415526960-f7e0328d2f82?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: Syringe,
      title: 'Aşılama',
      description: 'Koruyucu aşı programları ve takip hizmetleri',
      image: 'https://images.unsplash.com/photo-1624571243601-5e7b3b44e0c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: Scissors,
      title: 'Cerrahi İşlemler',
      description: 'Modern ameliyathane ile güvenli cerrahi müdahaleler',
      image: 'https://images.unsplash.com/photo-1625340915788-31c52f845ed9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Tooth,
      title: 'Diş Bakımı',
      description: 'Ağız ve diş sağlığı kontrolü ve tedavi hizmetleri',
      image: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-orange-500 to-orange-600'
    },
    {
      icon: FlaskConical,
      title: 'Laboratuvar',
      description: 'Kan tahlili, röntgen ve biyokimya testleri',
      image: 'https://images.unsplash.com/photo-1625841091050-665fbf7b6e20?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-red-500 to-red-600'
    },
    {
      icon: Heart,
      title: 'Acil Bakım',
      description: '7/24 acil durum müdahale ve yoğun bakım',
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      color: 'from-pink-500 to-pink-600'
    }
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Hizmetlerimiz
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Sevimli dostlarınız için kapsamlı veterinerlik hizmetleri sunuyoruz
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden"
              whileHover={{ y: -10 }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${service.color} opacity-80`}></div>
                <div className="absolute top-4 left-4">
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-full">
                    <service.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-blue-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {service.description}
                </p>
                <motion.button
                  className="text-blue-600 font-semibold hover:text-blue-800 transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Detayları Gör →
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-blue-600 to-green-500 rounded-2xl p-8 text-white">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Acil Bir Durumla mı Karşılaştınız?
            </h3>
            <p className="text-lg mb-6 opacity-90">
              7/24 acil servisimiz ile her zaman yanınızdayız
            </p>
            <motion.a
              href="tel:1724"
              className="inline-flex items-center bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Heart className="w-5 h-5 mr-2" />
              Hemen Ara: 1724
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
