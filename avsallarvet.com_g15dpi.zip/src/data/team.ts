export interface TeamMember {
  readonly id: string;
  readonly name: string;
  readonly image: string;
  readonly className: string;
}

export const teamMembers: TeamMember[] = [
  {
    id: 'ahmet-yilmaz',
    name: 'Dr. Ahmet Yılmaz',
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    className: "hidden shrink-0 w-[150px]"
  },
  {
    id: 'ayse-demir',
    name: 'Dr. Ayşe Demir',
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    className: "shrink-0 w-[150px]"
  },
  {
    id: 'mehmet-kaya',
    name: 'Dr. Mehmet Kaya',
    image: "https://randomuser.me/api/portraits/men/65.jpg",
    className: "hidden shrink-0 w-[150px]"
  }
] as const;
