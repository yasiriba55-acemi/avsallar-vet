export interface SocialMediaLink {
  readonly id: string;
  readonly name: string;
  readonly icon: string;
}

export const socialMediaLinks: SocialMediaLink[] = [
  {
    id: 'instagram',
    name: 'Instagram',
    icon: "https://c.animaapp.com/meg0x8ddQI8ex5/assets/733558.png"
  },
  {
    id: 'facebook',
    name: 'Facebook',
    icon: "https://c.animaapp.com/meg0x8ddQI8ex5/assets/733547.png"
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: "https://c.animaapp.com/meg0x8ddQI8ex5/assets/733646.png"
  }
] as const;
