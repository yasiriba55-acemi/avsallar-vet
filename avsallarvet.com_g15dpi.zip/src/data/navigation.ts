export interface LanguageOption {
  readonly code: string;
  readonly label: string;
}

export const languageOptions: LanguageOption[] = [
  { code: 'tr', label: 'Türkçe' },
  { code: 'en', label: 'English' },
  { code: 'de', label: 'Deutsch' },
  { code: 'ru', label: 'Русский' }
] as const;
